package tests;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import pages.BasePage;
//import pages.HomePage;
import pages.LoginPage;

//import ptest.utilities.ExcelReader;

import ptest.utilities.ExtentTestManager;
import ptest.utilities.PropertyFileRead;
import ptest.utilities.ReadExcel;
import ptest.utilities.TestListener;



public class LoginTests extends BasePage {

	//public static TestListener testListener;

	//public ReadExcel readExcel;
	//public ExcelReader excelRead;
	//public static BasePage basepage;
	//public ExtentTestManager extentTestManager;

	String browser = PropertyFileRead.FileRead("ProjectData.properties","BrowserType");
	String url = PropertyFileRead.FileRead("ProjectData.properties","baseurl");

	static WebDriver driver = BasePage.getDriver();

	//@Param
	//@Test(priority = 0 , dataProvider = "Login2Data")
	//Map<Object, Object> map
	@Test
	public void Login_With_Username_and_Password (Method method ,ITestContext iTestContext) throws IOException {

		

		ExtentTestManager.startTest(method.getName());

		String filePath = "\\src\\data\\LoginData.xlsx";		
		String SheetName = "Sheet1";
		String logicalName = "Test2";

		Map <String,Map<Integer, String>> tableMap = ReadExcel.readRow(logicalName, filePath, SheetName);

		for (int i = 0  ;i < tableMap.get("UserName").size();i++) {

			String username = tableMap.get("UserName").get(i);
			
			String password = tableMap.get("Password").get(i);
			

			BasePage.GoToURL(browser, url);				
			TestListener.createScreenShot(iTestContext);
			BasePage.click(PropertyFileRead.FileRead("ProjectData.properties","signInButtonClass"));
	
			LoginPage.loginToN11(username, password);
			BasePage.log("Login Test Passed");
			TestListener.createScreenShot(iTestContext);
		}


		/*	//@DataProvider(name="Login2Data")
	public Object[][] dataSupplier() throws Exception {

		String path = "LoginData.xlsx";
tf
		String SheetName = "Sheet1";

		String logicalName = "Test2";

		Object[][] mydata = ExcelReader.getData( path, SheetName,logicalName);

		return mydata;

	}*/

		/*    @Test(priority = 1)
    public void Verify_Title () {
        //ExtentReports Description
      //  ExtentTestManager.startTest(method.getName(), "Check Title");

        homePage
            .goToUrl()
            .goToLoginPage()
            .loginToN11("John Doe", "ThisIsNotAPassword")
            .verifyLoginUserName("Make Appointment");
            .verifyLoginPassword("WRONG MESSAGE FOR FAILURE!");
    }*/
	}
}
