package pages;

import java.util.Properties;
import ptest.utilities.PropertyFileRead;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

//import tests.BaseTest;

public class LoginPage extends BasePage {
	private static BasePage basepage;

/*    public LoginPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}*/

	/**Web Elements*/
 /*   By usernameTextBox = By.id("txt-username");
    By PasswordTextBox = By.id("txt-password");
    By loginButton = By.id("btn-login");*/
    By Title = By.xpath("//*[text()=\"Make Appointment\"]");
    //By errorMessagePasswordXpath = By.xpath("//*[@id=\"loginForm\"]/div[2]/div/div ");

    /**Page Methods*/
    public static void loginToN11(String username, String password) {
    	basepage.enterText(PropertyFileRead.FileRead("ProjectData.properties","usernameTextBox"),username);
    	basepage.enterText(PropertyFileRead.FileRead("ProjectData.properties","PasswordTextBox"),password);
     /*   writeText(usernameTextBox, username);
        writeText(PasswordTextBox, password);*/
       /* basetest.getScreenshot();*/
    	basepage.click(PropertyFileRead.FileRead("ProjectData.properties","loginButton"));
       // click(loginButton);
        Assert.assertTrue(true, "Passed");
       /* return this;*/
    }

    public LoginPage verifyLoginUserName(String expectedText) {
        waitVisibility(Title);
        Assert.assertEquals(readText(Title), expectedText);
        return this;
    }

/*    public LoginPage verifyLoginPassword(String expectedText) {
        waitVisibility(errorMessagePasswordXpath);
        Assert.assertEquals(readText(errorMessagePasswordXpath), expectedText);
        return this;
    }*/

}
