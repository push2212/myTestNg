package pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.SimpleTimeZone;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;

import com.relevantcodes.extentreports.LogStatus;

import ptest.utilities.ExtentTestManager;
import ptest.utilities.ReadExcel;


public class BasePage {
	public static WebDriver driver;
	public WebDriverWait wait;
	public static Properties prop;
	public  static EventFiringWebDriver e_driver;
	public static WebElement webelement;
	public static List<WebElement> webelements = null;
	public static int defaultBrowserTimeOut = 30000;
	public static List<String> windowHandlers;
	public static ReadExcel readExcel;



	public static WebDriver GoToURL(String browserName, String url)throws UnknownHostException {

		//deleteTempFile();

		if (browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir") + "\\geckodriver.exe");
			/*	DesiredCapabilities capabilities = DesiredCapabilities.firefox();
				capabilities.setCapability("marionette", true);
				Webdriver driver = new FirefoxDriver(capabilities);*/
			driver = new FirefoxDriver();
			driver.get(url);
		} else if (browserName.equalsIgnoreCase("iexplorer")) {
			System.setProperty("webdriver.ie.driver",
					System.getProperty("user.dir") + "\\IEDriverServer.exe");
			/*	DesiredCapabilities capabilities = DesiredCapabilities.

			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			capabilities.setCapability("ignoreZoomSetting", true);*/
			driver = new InternetExplorerDriver();
		} else if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") +"\\lib\\chromedriver.exe");				
			driver = new ChromeDriver(); 
			driver.get(url);
		}

		driver.manage().timeouts().implicitlyWait(defaultBrowserTimeOut, TimeUnit.MILLISECONDS);
		driver.manage().deleteAllCookies();

		if (browserName.equalsIgnoreCase("iexplorer"))
			SwitchToAlert();

		if (windowHandlers == null)
			windowHandlers = new LinkedList<String>();
		else
			windowHandlers.clear();

		windowHandlers.add(driver.getWindowHandle());
		driver.manage().window().maximize();
		return driver;

	}

	public static WebDriver getDriver() {
		return driver;
	}
	@AfterMethod
	public static void shutDownDriver() {
		if (driver != null)
			driver.quit();
	}





	/**

	 * @return Boolean value for Switch Alert
	 */
	public static boolean SwitchToAlert() {
		boolean Flag = false;

		try {
			if (driver.switchTo().alert() != null) {
				driver.switchTo().alert().accept();
				Flag = true;
			}

		}

		catch (NoAlertPresentException e) {

		}
		return Flag;

	}

	/**

	 * @param driver
	 * @param element
	 */
	public static void highlightElement(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
				element, "border: 2px solid DeepPink;");
	}


	/**

	 * @param locator in particular format mentioned
	 * @return WebElement
	 */
	public static WebElement findElement(String locator) {

		//Locator Values are Expected in string format like "name==abc" or "id==pqr" or "xpath==//*[@id='uname']"

		if (locator != null) {
			String[] arrLocator = locator.split("==");
			String locatorTag = arrLocator[0].trim();
			String objectLocator = arrLocator[1].trim();
			try {
				if (locatorTag.equalsIgnoreCase("id")) {
					webelement = driver.findElement(By.id(objectLocator));
					//highlightElement(driver, webelement);
				} else if (locatorTag.equalsIgnoreCase("name")) {
					webelement = driver.findElement(By.name(objectLocator));
					//highlightElement(driver, webelement);
				} else if (locatorTag.equalsIgnoreCase("xpath")) {
					webelement = driver.findElement(By.xpath(objectLocator));
					//highlightElement(driver, webelement);
				} else if (locatorTag.equalsIgnoreCase("linkText")) {
					webelement = driver.findElement(By.linkText(objectLocator));
					//highlightElement(driver, webelement);
				} else if (locatorTag.equalsIgnoreCase("class")) {
					webelement = driver
							.findElement(By.className(objectLocator));
					//highlightElement(driver, webelement);
				} else if (locatorTag.equalsIgnoreCase("css")) {
					webelement = driver.findElement(By
							.cssSelector(objectLocator));
					//highlightElement(driver, webelement);
				} else {
					String error = "Please Check the Given Locator Syntax :"
							+ locator;
					error = error.replaceAll("'", "\"");

					return null;
				}
			} catch (Exception e) {
				ExtentTestManager.getTest().log(LogStatus.FAIL, "Failure Reason:- "+e.getMessage());
				Assert.assertTrue(false);
				String error = "Please Check the Given Locator Syntax :"
						+ locator;
				error = error.replaceAll("'", "\"");
				e.printStackTrace();
				return null;				
				
			}
		}
		
		return webelement;
	}
	



	//Click Method
	public void click(By elementLocation) {
		waitVisibility(elementLocation);
		driver.findElement(elementLocation).click();
	}

	//Write Text
	public void writeText(By elementLocation, String text) {
		waitVisibility(elementLocation);
		driver.findElement(elementLocation).sendKeys(text);
	}

	//Read Text
	public String readText(By elementLocation) {
		waitVisibility(elementLocation);
		return driver.findElement(elementLocation).getText();
	}

	//Wait
	public void waitVisibility(By by){
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));		
	}
	public WebElement findByClassName(String ClassName) {
		WebElement element = driver.findElement(By.className(ClassName));

		return element;
	}




	/**
	 * Find WebElement By CssSelector.
	 *
	 * @param CssSelector
	 * @return Return Web Element.
	 */
	public WebElement findByCssSelector(String CssSelector) {
		WebElement element = driver.findElement(By.cssSelector(CssSelector));

		return element;
	}

	/**

	 * @param locator
	 * desc Whether the checkbox is checked or not 
	 */
	public static boolean isCheckboxChecked(String locator) {
		WebElement element = findElement(locator);
		if (element.isSelected())
			return true;
		else
			return false;
	}

	/**

	 * * @param locator
	 * @return list of webelement found
	 */
	public static List<WebElement> findElements(String locator) {

		if (locator != null) {
			String[] arrLocator = locator.split("==");
			String locatorTag = arrLocator[0].trim();
			String objectLocator = arrLocator[1].trim();

			if (locatorTag.equalsIgnoreCase("id")) {
				webelements = driver.findElements(By.id(objectLocator));
			} else if (locatorTag.equalsIgnoreCase("name")) {
				webelements = driver.findElements(By.name(objectLocator));
			} else if (locatorTag.equalsIgnoreCase("xpath")) {
				webelements = driver.findElements(By.xpath(objectLocator));
			} else if (locatorTag.equalsIgnoreCase("linkText")) {
				webelements = driver.findElements(By.linkText(objectLocator));
			} else if (locatorTag.equalsIgnoreCase("class")) {
				webelements = driver.findElements(By.className(objectLocator));
			} else {
				System.out.println("Please Check the Locator Syntax Given :"
						+ locator);
				return null;
			}
		}
		return webelements;
	}

	/**

	 * @param locator
	 * desc Check a Checkbox having a particular value as its attribute 
	 */
	public static void CheckCheckBox(String Locator, String Value)
	{
		List<WebElement> oCheckBox = findElements(Locator);


		// This will tell you the number of checkboxes are present

		int iSize = oCheckBox.size();

		// Start the loop from first checkbox to last checkbox

		for(int i=0; i < iSize ; i++ ){

			// Store the checkbox name to the string variable, using 'Value' attribute

			String sValue = oCheckBox.get(i).getAttribute("value");

			// Select the checkbox it the value of the checkbox is same what you are looking for

			if (sValue.equalsIgnoreCase(Value))
			{

				oCheckBox.get(i).click();

				// This will take the execution out of for loop

				break;

			}

		}
	}


	/**
	 * ram ID
	 * <p>
	 * Find Web Element By ID.
	 *
	 * @paturn Return Web Element.
	 */
	public WebElement findById(String ID) {
		WebElement element = driver.findElement(By.id(ID));

		return element;
	}

	/**

	 * @throws AWTException 
	 */
	public static void PressShiftTab() throws AWTException {
		Robot robot = new Robot();
		robot.delay(3000);
		robot.keyPress(KeyEvent.VK_SHIFT);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB); 
		robot.keyRelease(KeyEvent.VK_SHIFT);
	}

	/**

	 * @throws AWTException 
	 */
	public static void PressTab() throws AWTException {
		Robot robot = new Robot();
		robot.delay(3000);

		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB); 

	}
	/**

	 * @param locator of the Web Element
	 * @param attributeName
	 * @return attributeValue
	 */
	public static String getAttribute(String locator, String attributeName) {
		String attributeValue = null;
		try {

			WebElement element = findElement(locator);
			if (element != null)
				attributeValue = element.getAttribute(attributeName);
			element = null;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return attributeValue;
	}

	/**

	 * @param locator of the Element to be cleared
	 */
	public static void clearElement(String locator) {
		try {

			WebElement element = findElement(locator);
			element.clear();
			element = null;
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	/**

	 * @param locator
	 * @param value
	 */
	public static void enterText(String locator, String value) {

		try {

			WebElement element = findElement(locator);
			element.sendKeys(value);
			element = null;
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**

	 * @param locator of Element to be clicked
	 * @return 
	 */
	public static  void click(String locator) {
		try {
			WebElement element = findElement(locator);
			if (element != null)
				element.click();
			else
				System.out.println("Element Is NULL");
			element = null;		
			/*Assert.assertTrue(false);*/

		} catch (Exception e) {

			System.out.println(" Error occured whlie click on the element "
					+ locator + " *** " + e.getMessage());
			ExtentTestManager.getTest().log(LogStatus.FAIL, "Failure Reason:- "+e.getMessage());
			Assert.assertTrue(false);
		}
	}

	/**

	 * @param locator
	 * @return Text/value of the Element
	 */
	public static String getElementText(String locator) {
		WebElement element;
		String text = null;
		try {
			element = findElement(locator);
			if (element != null)

				text = element.getText();

		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, "Failure Reason:- "+e.getMessage());
			Assert.assertTrue(false);
		}
		element = null;

		return text;
	}

	/**

	 * @param propertyType
	 * @param propertyValue
	 */
	public static void mouseHover(String locator) {

		WebElement mouseOverElement = findElement(locator);
		Actions builder = new Actions(driver);  // Configure the Action    
		Action mouseOver =builder.moveToElement(mouseOverElement).build(); // Get the action    
		mouseOver.perform(); // Execute the Action 
	}

	/**
	 * Find Web Element By findByLinkText.
	 *
	 * @param linkText
	 * @return Return Web Element.
	 */
	public WebElement findByLinkText(String linkText) {
		WebElement element = driver.findElement(By.linkText(linkText));

		return element;
	}

	/**
	 * Find Web Element By Name.
	 *
	 * @param Name
	 * @return Return Web Element.
	 */
	public WebElement findByName(String Name) {
		WebElement element = driver.findElement(By.name(Name));

		return element;
	}

	/**
	 * Find Web Element By Partial_Link_Text.
	 *
	 * @param PartialLinkText
	 * @return Return Web Element.
	 */
	public WebElement findByPartialLinkText(String PartialLinkText) {
		WebElement element = driver.findElement(By.partialLinkText(PartialLinkText));

		return element;
	}

	/**
	 * Find Web Element By Tag_Name.
	 *
	 * @param TagName
	 * @return Return Web Element.
	 */
	public WebElement findByTagName(String TagName) {
		WebElement element = driver.findElement(By.tagName(TagName));

		return element;
	}

	/**
	 * Find Web Element By findByXpath.
	 *
	 * @param XpathExpression
	 * @return Return Web Element.
	 */
	public WebElement findByXpath(String XpathExpression) {
		WebElement element = driver.findElement(By.xpath(XpathExpression));

		return element;
	}


	public boolean elementIsDisplayed(WebElement Element) {
		boolean Value = Element.isDisplayed();

		return Value;
	}

	public boolean elementIsSelected(WebElement Element) {
		boolean Value = Element.isSelected();

		return Value;
	}

	/**
	 * Get Element currently Enabled or not.
	 *
	 * @param Element Enter Web Element.
	 * @return Return Boolean Value (True Or False).
	 */
	public boolean elementIsEnabled(WebElement Element) {
		boolean Value = Element.isEnabled();
		return Value;
	}


	/**
	 * Wait Script.
	 *
	 * @param secs Enter Sec Value.
	 * Pause Or Sleep Script For Entered Sec.
	 */
	public void sleep(int secs) {
		try {
			Thread.sleep(secs * 1000);
		} catch (InterruptedException interruptedException) {

		}
	}

	/**
	 * Highlight Element.
	 *
	 * @param Element Highlight Element With Solid Yellow Border.
	 */
	//Highlight Element.
	/*	public void highlightElement(WebElement Element) {

		((JavascriptExecutor) driver).executeScript("arguments[0].style.border = '3px solid yellow'", Element);
		pause(2);
	}*/


	/**
	 * Perform Alert Accept Operation.
	 * <p>
	 * Accept Or Ok Alert.
	 */
	public void alertAccept() {
		Alert alert = driver.switchTo().alert();
		alert.accept();
	}

	/**
	 * Perform Alert Dismiss Operation.
	 * <p>
	 * Close Or Cancel Alert.
	 */
	//
	public void alertDismiss() {
		Alert alert = driver.switchTo().alert();
		alert.dismiss();
	}

	/**
	 * Get Alert Text.
	 *
	 * @return Return Alert Text.
	 */
	//
	public String getAlertText() {
		Alert alert = driver.switchTo().alert();
		String AlertText = alert.getText();
		return AlertText;
	}

	/**
	 * Send Text On Alert.
	 *
	 * @param Text Type Text On Alert.
	 */
	public void sendTextOnAlert(String Text) {
		Alert alert = driver.switchTo().alert();
		alert.sendKeys(Text);
	}


	/**
	 * Get Current Date And Time.
	 *
	 * @return Return Current Date & Time.
	 */
	public String getCurrentDateTime() {
		Date date = new Date();

		SimpleDateFormat sd = new SimpleDateFormat("dd-MM-YYYY|HH:mm:ss:SS");
		TimeZone timeZone = TimeZone.getDefault();
		Calendar cal = Calendar.getInstance(new SimpleTimeZone(timeZone.getOffset(date.getTime()), "GMT"));
		sd.setCalendar(cal);
		return sd.format(date);
	}

	/**
	 * Generate Random Numeric Number.
	 *
	 * @param Length Enter String Length In Integer.
	 * @return Return Random Numeric String.
	 */
/*	public String generateRandomNumber(int Length) {

		String RandomNumber = RandomStringUtils.randomNumeric(Length);
		return RandomNumber;

	}*/

	/**
	 * Generate Random AlphaNumeric String.
	 *
	 * @param Length Enter String Length In Integer.
	 * @return Return Random AlphaNumeric String.
	 */
	public static String getRandomNumString(int n) 
	{ 

		// length is bounded by 256 Character 
		byte[] array = new byte[256]; 
		new Random().nextBytes(array); 

		String randomString 
		= new String(array, Charset.forName("UTF-8")); 

		// Create a StringBuffer to store the result 
		StringBuffer r = new StringBuffer(); 

		// Append first 20 alphanumeric characters 
		// from the generated random String into the result 
		for (int k = 0; k < randomString.length(); k++) { 

			char ch = randomString.charAt(k); 

			if (((ch >= 'a' && ch <= 'z') 
					|| (ch >= 'A' && ch <= 'Z') 
					|| (ch >= '0' && ch <= '9')) 
					&& (n > 0)) { 

				r.append(ch); 
				n--; 
			} 
		} 

		// return the resultant string 
		return r.toString(); 
	} 

	/**
	 * Generate Random AlphaBetic String.
	 *
	 * @param Length Enter String Length In Integer.
	 * @return Return Random Alphabetic String.
	 **/
	/*	public String generateRandomAlphabetic(int Length) {
		String RandomName = RandomStringUtils.randomAlphabetic(Length);
		return RandomName;
	}*/

	/**
	 * Generate Random AlphaAscii String.
	 *
	 * @param Length Enter String Length In Integer.
	 * @return Return Random Ascii String.
	 *//*
	public String generateRandomAscii(int Length) {
		String RandomAscii = RandomStringUtils.randomAscii(Length);
		return RandomAscii;
	}
	  */

	public static void log(String msg) {

		Reporter.log(msg);
		System.out.println(msg);
	}


	public List<WebElement> findListOfElementsByXpath(String Xpath) {
		List<WebElement> elements = driver.findElements(By.xpath(Xpath));
		return elements;
		//WebElement element = elements.get(1);
		//element.browser();
	}

	/**
	 * List Of Web Elements Find By Name.
	 *
	 * @param Name Enter Name In String.
	 * @return Return List Of Web Elements.
	 */
	public List<WebElement> findListOfElementsByName(String Name) {
		List<WebElement> elements = driver.findElements(By.name(Name));
		return elements;
	}

	/**
	 * List Of Web Elements Find By Id.
	 *
	 * @param Id Enter Id In String.
	 * @return Return List Of Web Elements.
	 */
	public List<WebElement> findListOfElementsById(String Id) {
		List<WebElement> elements = driver.findElements(By.id(Id));
		return elements;
	}

	/**
	 * List Of Web Elements Find By Class Name.
	 *
	 * @param ClassName Enter Class Name In String.
	 * @return Return List Of Web Elements.
	 */
	public List<WebElement> findListOfElementsByClassName(String ClassName) {
		List<WebElement> elements = driver.findElements(By.className(ClassName));
		return elements;
	}

	/**
	 * List Of Web Elements Find By Css Selector.
	 *
	 * @param CssSelector Enter Css Selector In String.
	 * @return Return List Of Web Elements.
	 */
	public List<WebElement> findListOfElementsByCssSelector(String CssSelector) {
		List<WebElement> elements = driver.findElements(By.cssSelector(CssSelector));
		return elements;
	}

	/**
	 * List Of Web Elements Find By Link Text.
	 *
	 * @param LinkText Enter Link Text In String.
	 * @return Return List Of Web Elements.
	 */
	public List<WebElement> findListOfElementsByLinkText(String LinkText) {
		List<WebElement> elements = driver.findElements(By.linkText(LinkText));
		return elements;
	}

	/**
	 * List Of Web Elements Find By Partial Link Text.
	 *
	 * @param PartialLinkText Enter Partial Link Text In String.
	 * @return Return List Of Web Elements.
	 */
	public List<WebElement> findListOfElementsByPartialLinkText(String PartialLinkText) {
		List<WebElement> elements = driver.findElements(By.partialLinkText(PartialLinkText));
		return elements;
	}

	/**
	 * List Of Web Elements Find By Tag Name.
	 *
	 * @param TagName Enter Tag Name In String.
	 * @return Return List Of Web Elements.
	 */
	public List<WebElement> findListOfElementsByTagName(String TagName) {
		List<WebElement> elements = driver.findElements(By.tagName(TagName));
		return elements;
	}


	//----------------------------------------------------------------------------------------------------


	/*public void waitForElementToBeDisapper(String fileName, String elementName) {


		try {


			String locatorType = (String) elementProperty.get("locatorType");
			String locatorValue = (String) elementProperty.get("locatorValue");
			WebElement element = null;

			if (locatorType.equals("xpath")) {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(locatorValue)));
			}

			if (locatorType.equals("id")) {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(locatorValue)));
			}

			if (locatorType.equals("className")) {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className(locatorValue)));
			}

			if (locatorType.equals("tagName")) {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.tagName(locatorValue)));
			}


			if (locatorType.equals("linkText")) {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.linkText(locatorValue)));
			}


			if (locatorType.equals("partialLinkText")) {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.partialLinkText(locatorValue)));
			}


			if (locatorType.equals("name")) {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.name(locatorValue)));
			}

			if (locatorType.equals("cssSelector")) {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(locatorValue)));
			}

		} catch (Exception e) {
		}
	}*/


	/*	public void waitForElement(String fileName, String elementName) {

		try {		

			String locatorType = (String) elementProperty.get("locatorType");
			String locatorValue = (String) elementProperty.get("locatorValue");
			WebElement element = null;

			if (locatorType.equals("xpath")) {
				wait.until(visibilityOfElementLocated(By.xpath(locatorValue)));
			}

			if (locatorType.equals("id")) {
				wait.until(visibilityOfElementLocated(By.id(locatorValue)));
			}

			if (locatorType.equals("className")) {
				wait.until(visibilityOfElementLocated(By.className(locatorValue)));
			}

			if (locatorType.equals("tagName")) {
				wait.until(visibilityOfElementLocated(By.tagName(locatorValue)));
			}

			if (locatorType.equals("linkText")) {
				wait.until(visibilityOfElementLocated(By.linkText(locatorValue)));
			}

			if (locatorType.equals("partialLinkText")) {
				wait.until(visibilityOfElementLocated(By.partialLinkText(locatorValue)));
			}

			if (locatorType.equals("name")) {
				wait.until(visibilityOfElementLocated(By.name(locatorValue)));
			}

			if (locatorType.equals("cssSelector")) {
				wait.until(visibilityOfElementLocated(By.cssSelector(locatorValue)));
			}

		} catch (Exception e) {
		}
	}*/


	/*
	public WebElement findElement(String fileName, String value) {



		String locatorType = (String) elementProperty.get("locatorType");
		String locatorValue = (String) elementProperty.get("locatorValue");

		WebElement element = null;

		if (locatorType.equals("xpath")) {
			element = findByXpath(locatorValue);
		}
		if (locatorType.equals("id")) {
			element = findById(locatorValue);
		}
		if (locatorType.equals("className")) {
			element = findByClassName(locatorValue);
		}
		if (locatorType.equals("tagName")) {
			element = findByTagName(locatorValue);
		}
		if (locatorType.equals("linkText")) {
			element = findByLinkText(locatorValue);
		}
		if (locatorType.equals("partialLinkText")) {
			element = findByPartialLinkText(locatorValue);
		}
		if (locatorType.equals("name")) {
			element = findByName(locatorValue);
		}
		if (locatorType.equals("cssSelector")) {
			element = findByCssSelector(locatorValue);
		}

		return element;
	}
	 */

	/*public List<WebElement> findElementList(String fileName, String elementName) {

		List<WebElement> elementList = null;

		String locatorType = (String) elementProperty.get("locatorType");
		String locatorValue = (String) elementProperty.get("locatorValue");

		if (locatorType.equals("xpath")) {
			elementList = findListOfElementsByXpath(locatorValue);
		}

		if (locatorType.equals("id")) {
			elementList = findListOfElementsById(locatorValue);
		}

		if (locatorType.equals("className")) {
			elementList = findListOfElementsByClassName(locatorValue);
		}

		if (locatorType.equals("tagName")) {
			elementList = findListOfElementsByTagName(locatorValue);
		}


		if (locatorType.equals("linkText")) {
			elementList = findListOfElementsByLinkText(locatorValue);
		}

		if (locatorType.equals("partialLinkText")) {
			elementList = findListOfElementsByPartialLinkText(locatorValue);
		}

		if (locatorType.equals("name")) {
			elementList = findListOfElementsByName(locatorValue);
		}

		if (locatorType.equals("cssSelector")) {
			elementList = findListOfElementsByCssSelector(locatorValue);
		}

		return elementList;
	}
	 */



}