/*package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import ptest.utilities.PropertyFileRead;

public class HomePage extends BasePage {
	
	private static BasePage basepage;

	*//**Constructor*//*
	public HomePage(WebDriver driver) {
		super(driver);
	}

	*//**Variables*//*
	String baseURL = PropertyFileRead.FileRead("ProjectData.properties","baseurl");
	
	


	*//**Web Elements*//*
	By signInButtonClass = By.id("btn-make-appointment");
	WebElement signInButtonClass1 = findElement("id==btn-make-appointment");
	
	
			

	*//**Page Methods*//*
	public HomePage goToUrl() {	
		System.out.println(baseURL); 
		driver.get(baseURL);
		return this;
	}

	public LoginPage goToLoginPage() {	
		System.out.print("Lpage "); 
		basepage.click(PropertyFileRead.FileRead("ProjectData.properties","signInButtonClass"));
		click(signInButtonClass);		
		return new LoginPage(driver);
	}
}*/