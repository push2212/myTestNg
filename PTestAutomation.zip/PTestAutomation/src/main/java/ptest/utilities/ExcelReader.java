/*package ptest.utilities;
import java.io.File;
import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;
import java.io.FileOutputStream;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class ExcelReader{

	public static Map<String,  Map<String, String>> setMapData() throws IOException {

		String path = "C:\\ExtentReportsExample-master\\src\\data\\LoginData.xlsx";

		FileInputStream fis = new FileInputStream(path);

		Workbook workbook = new XSSFWorkbook(fis);

		Sheet sheet = workbook.getSheetAt(0);

		int lastRow = sheet.getLastRowNum();

		Map<String, Map<String, String>> excelFileMap = new HashMap<String, Map<String,String>>();

		Map<String, String> dataMap = new HashMap<String, String>();

		//Looping over entire row
		for(int i=0; i<=lastRow; i++){

			Row row = sheet.getRow(i);

			int columnCount=row.getLastCellNum();			

			for(int j=0;j<columnCount;j++)
			{				

				//1st Cell as Value
				Cell valueCell = row.getCell(i);

				//0th Cell as Key
				Cell keyCell = row.getCell(j);

				String value = valueCell.getStringCellValue().trim();
				String key = keyCell.getStringCellValue().trim();

				//Putting key & value in dataMap
				dataMap.put(key, value);

				//Putting dataMap to excelFileMap
				excelFileMap.put("DataSheet", dataMap);
			}
		}

		//Returning excelFileMap
		return excelFileMap;

	}

	//Method to retrieve value
	public static String getMapData(String key) throws IOException{

		Map<String, String> m = setMapData().get("DataSheet");
		String value = m.get(key);

		return value;

	}

}




*/