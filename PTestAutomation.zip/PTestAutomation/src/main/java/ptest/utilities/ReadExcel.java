package ptest.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;
//import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.*;



public class ReadExcel {

	/*	static ArrayList < String > Exceldata = new ArrayList < String > ();

	public static ArrayList<String> getTestData(String FilePath,String sFirstCollumnValue ,String sheetName)
	{
		String currentDir = System.getProperty("user.dir");
		FilePath = currentDir.concat(FilePath);
		try {
			FileInputStream FIS=new FileInputStream(FilePath);
			XSSFWorkbook Workbook = new XSSFWorkbook(FIS);

			XSSFSheet objsheet = Workbook.getSheet(sheetName);
			int rowcount= objsheet.getLastRowNum();
			for(int a=0 ; a<=rowcount; a++)
			{
				XSSFRow row = objsheet.getRow(a);


				int collumCount=row.getLastCellNum();
				String colummnvalue=row.getCell(0).getStringCellValue();

				if (colummnvalue.equals(sFirstCollumnValue) )
				{
					//this.report("pass", "value found in Excel sheet ");
					for(int b=0;b<collumCount;b++)
					{
						String value= row.getCell(b).getStringCellValue();
						//System.out.print(" " +value);
						//this.report("info","value from excel "+value);
						Exceldata.add(value);                       
					}
				}
			}			
			Workbook.close();
			FIS.close();           
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return Exceldata;

	}*/


	public static Map<String, Map<Integer, String>> readRow(String row, String filePath, String dataSheet) throws IOException{
		System.out.println(filePath);
		Map <String,Map<Integer, String>> tableMap = new HashMap<String, Map<Integer, String>>();

		try{

			String currentDir = System.getProperty("user.dir");
			filePath = currentDir.concat(filePath);
			System.out.println(filePath);
			FileInputStream inputStream = new FileInputStream(new File(filePath));

			Workbook workbook = new XSSFWorkbook(inputStream);


			XSSFSheet datatypeSheet = (XSSFSheet) workbook.getSheet(dataSheet);

			Iterator<Row> iterator = datatypeSheet.iterator();


			Row firstRow = iterator.next();
			Iterator<Cell> firstRowCell = firstRow.iterator();
			List<String> cellNames = new ArrayList<String>();
			firstRowCell.next();
			while (firstRowCell.hasNext()){
				//
				Cell cell = firstRowCell.next();
				cellNames.add(cell.getStringCellValue());
			}
			List<Integer> totalRows = new ArrayList<Integer>();
			String flag = "";
			while (iterator.hasNext()) {

				Row currentRow = iterator.next();

				String currRow = currentRow.getCell(0).getStringCellValue();

				if (row.equals(currRow)){
					totalRows.add(currentRow.getRowNum());
					flag = "found";
				} else if (flag == "found"){
					break;
				}

			}
			if (!flag.equals("found")){
				//report.Info("Logical Name " + row + " not found in the sheet " + dataSheet);
				Assert.assertTrue(false);        	 
			}

			int i = 1;
			for (String x : cellNames){
				int k = 0; 
				Map<Integer,String> entireRow = new HashMap<Integer,String>();
				for (Integer y : totalRows){
					Row currRow = datatypeSheet.getRow(y);
					String cellContent = "";
					if (currRow.getCell(i) == null){
						cellContent = "";
					}else if (currRow.getCell(i).getCellType() == CellType.STRING){
						cellContent = currRow.getCell(i).getStringCellValue();
					}else if (currRow.getCell(i).getCellType() == CellType.NUMERIC){
						cellContent = String.valueOf(currRow.getCell(i).getNumericCellValue());
					}
					else if (currRow.getCell(i).getCellType() == CellType.BLANK){
						cellContent = "";
					}
					entireRow.put(k, cellContent);
					k = k + 1;
				}
				tableMap.put(x, entireRow);
				i =i +1;

			}

		}	catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e){
			e.printStackTrace();
		}
		return tableMap;

	}


}


